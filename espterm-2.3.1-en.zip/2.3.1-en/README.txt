This is a release archive of ESPTerm,
the VT100 terminal emulator for ESP8266.

--------------------------------------------
Version: 2.3.1
Locale : en
Built  : Sun 21 Jan 2018 02:10:23 PM CET
--------------------------------------------

Source repository:
  https://github.com/espterm/espterm-firmware

Report any bugs to our bug-tracker at
  https://github.com/espterm/espterm-firmware/issues
or send them to out mailing list
  espterm-dev@googlegroups.com

On-line demo is available at
  https://espterm.github.io/term.html

[EOF]
